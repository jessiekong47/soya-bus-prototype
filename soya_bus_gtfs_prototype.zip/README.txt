SOYA BUS GTFS PROTOTYPE
Built from the uploaded 天北宗谷岬線 timetable.

IMPORTANT:
- Prototype only; not official Soya Bus data.
- Stop coordinates are approximate/interpolated to make a functioning GTFS feed.
- Service calendar is assumed daily and MUST be verified.
- Includes complete timetable columns transcribed for Wakkanai Station Terminal <-> Onishibetsu Terminal:
  outbound/up trips 2, 4, 6, 8 and inbound/down trips 1, 2, 4, 6.
- Does not yet include the full Onishibetsu <-> Hamatonbetsu continuation or intercity Tenpoku service.
